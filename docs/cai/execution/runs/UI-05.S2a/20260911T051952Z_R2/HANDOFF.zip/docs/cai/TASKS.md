# 작업표 (파생 뷰)

정본은 [tasks.json](tasks.json)이다. 본 문서는 사람이 읽는 파생 표이며,
JSON과 별도로 상태를 관리하지 않는다. READY·DOING·BLOCKED는 별도 집계한다.

<!-- counts: total=14 REVIEW=4 DONE=1 DOING=0 TODO=9 BLOCKED=0 READY=0 -->

- 총 작업 14 · 제출된 결과 5 (BOOT-01 · DATA-01 · OPS-01 · UI-05.S2a R2 REVIEW, REP-01 DONE)
- REVIEW 4 · DONE 1 · 진행 중(DOING+BLOCKED) 0 · 예정(TODO) 9

| 작업 ID | 상태 | 남은 조건 | 증거 | 다음 행동 |
|---|---|---|---|---|
| BOOT-01 | REVIEW | 원장 반영 확인 | runs/BOOT-01/20260911T025319Z/RESULT.md | 후속 단위 진행 |
| DATA-01 | REVIEW | TOP3 미채택/보류 확정됨 | runs/DATA-01/20260911T030713Z/RESULT.md, R1 | 다음 실행은 UI-05.S2a |
| OPS-01 | REVIEW | 원인 해소(대시보드) | runs/OPS-01/20260911T033847Z/RESULT.md·COMMANDS.md | REL-01 조건 재확인 |
| REP-01 | DONE | 없음(문서 세팅 완료) | runs/REP-01/20260911T042017Z/RESULT.md | UI-05.S1a/S2a 승인 요청 |
| UI-05.S1a | TODO | REP-01 확인 + DEC-02 IA·로컬 승인 | — | 승인 후 착수 |
| UI-05.S2a | REVIEW | 검토자 확인 | runs/UI-05.S2a/20260911T043814Z/RESULT.md, R1, R2 | 다음 카드 승인 요청 |
| UI-05.S1b | TODO | S1a·S2a 완료 + 승인 | — | 선행 완료 후 승인 요청 |
| UI-05.S2b | TODO | S2a 완료 + 승인 | — | 선행 완료 후 승인 요청 |
| UI-05.S2c | TODO | S1b·S2b 완료 + 승인 | — | 선행 완료 후 승인 요청 |
| UI-05.S3a | TODO | S2c 완료 + 승인 | — | 선행 완료 후 승인 요청 |
| UI-05.S3b | TODO | S3a 완료 + 승인 | — | 선행 완료 후 승인 요청 |
| UI-06 | TODO | S3b 완료 + 게시 승인 | — | 선행 완료 후 승인 요청 |
| QA-02 | TODO | UI-06 완료 + 검수 승인 | — | 선행 완료 후 승인 요청 |
| REL-01 | TODO | QA-02·OPS-01 조건 + 배포 승인 | — | 전제 해소 후 승인 요청 |

공통 차단: CI 결제/한도, Vercel BLOCKED(근본 미확인), 팀 승인 미확인,
로컬·원격 HEAD 상이(동기화 미승인). 담당 수락은 추정하지 않음(전원 미확인).
로컬 구현 차단 조건과 원격 검수·배포 차단 조건은 구분한다.
